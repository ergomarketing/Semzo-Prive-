// Re-export from app/lib for deployment compatibility
export { EmailServiceProduction } from "@/app/lib/email-service-production"
