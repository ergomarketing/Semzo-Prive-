// Re-export from app/lib for deployment compatibility
export { EmailService } from "@/app/lib/email-service"
