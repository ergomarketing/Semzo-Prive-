// Re-export from app/lib for deployment compatibility
export { authService } from "@/app/lib/supabase-auth"
