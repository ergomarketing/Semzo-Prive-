// Re-export from app/lib for deployment compatibility
export { emailLogger } from "@/app/lib/email-logger"
