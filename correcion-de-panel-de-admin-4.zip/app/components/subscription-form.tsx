"use client"

import EnhancedSubscriptionForm from "./form-validation"

export default function SubscriptionForm() {
  return <EnhancedSubscriptionForm />
}
