export default function VersionIndicator() {
  return null
}
