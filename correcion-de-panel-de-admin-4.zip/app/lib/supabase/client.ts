import { getSupabaseBrowser } from "@/app/lib/supabaseClient"

export const createBrowserSupabaseClient = getSupabaseBrowser

export { getSupabaseBrowser }
