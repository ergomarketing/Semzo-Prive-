import { createClient as createServerClient } from "@/app/lib/supabaseServer"

export const createClient = createServerClient

export { createServerClient }
